package petproject.petproject.model;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import petproject.petproject.model.Pet;

/**
 * Unit test for simple App.
 */
public class PetTest 
    extends TestCase
{

	/**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public PetTest( String PetTest )
    {
        super( PetTest );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( PetTest.class );
    }

  
    public void testPet()
    {
    	Pet testdog1 = new Pet(12345,"Joy1","dog","canis","canis1.jpeg","Available" );
    	Pet testdog2 = new Pet(67890,"Joy2","dog","canis","canis2.jpeg","Available" );
        PrintPet(testdog1);
        PrintPet(testdog2);
    	assertTrue( true );
    }
    
    public static void PrintPet(Pet pet) 
    {
    	System.out.println("Pet Id:" + pet.getId() );
    	System.out.println("Pet Name:" + pet.getName() );
    	System.out.println("Pet URL:" + pet.getUrl() );
    	System.out.println("Pet Status:" + pet.getStatus() );
    	
    	System.out.println("Pet Category Id:"   + pet.getCategory().getId() );
    	System.out.println("Pet Category Name:" + pet.getCategory().getName() );
    	
    	System.out.println("Pet Tags Id:" + pet.getTags().getId() );
    	System.out.println("Pet Tags Id:" + pet.getTags().getName() );
    	
    	
    }
}
