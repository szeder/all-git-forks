package petproject.common;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import petproject.petproject.DAO.PetDao;
import petproject.petproject.model.*;

public class App 
{
    public static void main( String[] args )
    {
    	String petinfo;
    	
    	@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-Module.xml");
    	 
        PetDao petdao = (PetDao) context.getBean("PetDao");
        Pet testdog1 = new Pet(12345,"Joy1","dog","canis","canis1.jpeg","Available" );
        petdao.CreatePet(testdog1);
    	
        petinfo = petdao.findPetById(12345);
        System.out.println("Pet infos:" + petinfo);
        
                
    }
}
