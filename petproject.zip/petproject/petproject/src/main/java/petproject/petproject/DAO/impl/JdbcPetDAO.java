package petproject.petproject.DAO.impl;

import java.sql.Connection;
/** import java.sql.DriverManager; **/
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import petproject.petproject.DAO.*;
import petproject.petproject.model.*;

public class JdbcPetDAO implements PetDao
{
	private DataSource dataSource; 
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	} 
	
	public void CreatePet(Pet pet){
		
		String sql = "CREATE PET: " +
				"(ID,NAME,CATEGORY,TAGS,PHOTOURLS,STATUS) VALUES (?, ?, ?, ?, ?, ?)";
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection(); 
			/** conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database" +
                    "user=seb&password=seb"); **/
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, pet.getId());
			ps.setString(2, pet.getName());
			ps.setInt(1, pet.getCategory().getId());
			ps.setString(3, pet.getCategory().getName());
			ps.setInt(1, pet.getTags().getId());
			ps.setString(4, pet.getTags().getName());
			ps.setString(5, pet.getUrl());
			ps.setString(6, pet.getStatus());
			ps.executeUpdate();
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	public String findPetById(int petId){
		
		String sql         = "SELECT * FROM PET WHERE Id = ?";	
		String sqlcategory = "SELECT * FROM CATEGORY WHERE Id = ?";
		String sqltags     = "SELECT * FROM TAGS WHERE Id = ?";
		String petsearch;
		String categorysearch;
		String tagssearch;
		
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection(); 
			/**conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database" +
                    "user=seb&password=seb");**/
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, petId);
			
			PreparedStatement pscategory = conn.prepareStatement(sqlcategory);
			pscategory.setInt(1, petId);
			
			PreparedStatement pstags = conn.prepareStatement(sqltags);
			pstags.setInt(1, petId);
				
			ResultSet rs = ps.executeQuery();
			ResultSet rscategory = ps.executeQuery();
			ResultSet rstags = ps.executeQuery();
			
			petsearch = null;
			if (rs.next())  {
				petsearch = 
					"PET ID=" + rs.getInt("ID")
					+ 
					"PET NAME=" + rs.getString("NAME") 
					+ 
					"PHOTOURLS= " + rs.getString("PHOTOURLS")					
					+ 
					"STATUS=" + rs.getString("STATUS");
			}
				
			categorysearch = null;
		    if (rscategory.next())  {
				   categorysearch = 
						"CATEGORY ID = " + rscategory.getInt("ID")
						+ 
						"CATEGORY NAME = " + rscategory.getString("NAME"); 
		    }
			
		    tagssearch =null;
			if (rstags.next())  {
					   tagssearch = 
							"TAGS ID = " + rstags.getInt("ID")
							+ 
							"TAGS NAME = " + rstags.getString("NAME"); 
		    }
	
			
			rs.close();
			ps.close();
			
			rscategory.close();
			pscategory.close();
			
			rstags.close();
			pstags.close();
			
			return (petsearch + categorysearch + tagssearch);
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	public void deletePet(int petId) {
		
		String sql         = "SELECT * FROM PET WHERE Id = ?";
		String sqlcategory = "SELECT * FROM CATEGORY WHERE Id = ?";
		String sqltags     = "SELECT * FROM TAGS WHERE Id = ?";
		
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection(); 
			/** conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database" +
                    "user=seb&password=seb"); **/
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, petId);	
			ResultSet rs = ps.executeQuery();
			if (rs.first()) { 
			  rs.deleteRow();					
			}
			rs.close();
			ps.close();
			
			PreparedStatement pscategory = conn.prepareStatement(sqlcategory);
			pscategory.setInt(1, petId);	
			ResultSet rscategory  = pscategory.executeQuery();
			if (rscategory.first()) { 
			  rscategory.deleteRow();					
			}
			rscategory.close();
			pscategory.close();
			
			PreparedStatement pstags = conn.prepareStatement(sqltags);
			pstags.setInt(1, petId);	
			ResultSet rstags = pstags.executeQuery();
			if (rstags.first()) { 
			  rstags.deleteRow();					
			}
			rstags.close();
			pstags.close();						
						
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
		
	}

	public void DeletePet(int petId) {
		// TODO Auto-generated method stub
		
	}	
	
}