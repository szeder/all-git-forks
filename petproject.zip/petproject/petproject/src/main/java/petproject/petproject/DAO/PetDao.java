package petproject.petproject.DAO;

import petproject.petproject.model.Pet;

public interface PetDao {

	public void CreatePet(Pet pet);	
	public String findPetById(int petId);
	public void DeletePet(int petId);

}
