package petproject.petproject.model;

public class Tags {
	
	private Integer id;
	private String name;

	public Tags (Integer id,  
	    	String name) {
	    	
	        this.id = id;
	        this.name = name;
	       	       
	    }
	    
	    /** return the id **/
	    public Integer getId() {
	        return id;
	    }
	    
	    /** return the name**/
	    public String getName() {
	        return name;
	    }
	    
}