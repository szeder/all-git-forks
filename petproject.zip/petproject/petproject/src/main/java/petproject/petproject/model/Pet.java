package petproject.petproject.model;

import petproject.petproject.model.Category;
import petproject.petproject.model.Tags;

public class Pet 
{
	
	    private Integer id;
	    protected Category category;
	    private String name;
	    private String photoUrls;
	    protected  Tags tags;
	    private String status;
		
	    	  	    
	    public Pet(Integer id,  
	    		    String name,
	    		    String namecategory,
	    		    String nametags,
	    		    String photoUrls, 
	    		    String status) {
	    	
	        this.id = id;
	        this.name = name;	        
	        category = new Category(id, namecategory);	        
	        this.photoUrls = photoUrls;
	        Tags tags = new Tags(id, nametags);	
	        this.tags = tags;
	        this.status = status;
	       
	    }
	    
	    /** return the id **/
	    public Integer getId() {
	        return id;
	    }
	    
	    /** return the name**/
	    public String getName() {
	        return name;
	    }
	    
	    /** return the category**/
	    public Category getCategory() {
	        return category;
	    }
	    
	    /** return the URL**/
	    public String getUrl() {
	        return photoUrls;
	    }
	    
	    /** return the tag**/
	    public Tags getTags() {
	        return tags;
	    }
	    
	    /** return the status**/
	    public String getStatus() {
	        return status;
	    }
	    
   
}
