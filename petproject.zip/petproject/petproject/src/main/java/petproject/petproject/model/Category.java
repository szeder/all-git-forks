package petproject.petproject.model;

public class Category {
	
	private Integer id;
	private String name;

	public Category (Integer id,  
	    	String name) {
	    	
	        this.id = id;
	        this.name = name;
	       	       
	    }
	    
	    /** return the id **/
	    public Integer getId() {
	        return id;
	    }
	    
	    /** return the name**/
	    public String getName() {
	        return name;
	    }
	    
}